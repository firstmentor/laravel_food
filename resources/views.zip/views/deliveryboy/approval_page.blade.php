@extends('commonmaster') 
@section('main_body')
<div class="col-md-3"></div>
<div class="col-md-6" style="margin-top:50px;"> <br>
	<div class="box box-primary">
		<div class="box-header with-border">
		  <h3 class="box-title">Welcome In AgFoods</h3>
		</div> 
	</div>
	<h3><a href="#">Click here</a> ! To Download an app</h3> 
</div>
@endsection