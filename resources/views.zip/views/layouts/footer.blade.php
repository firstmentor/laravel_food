<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.2.0
    </div>
    <strong>Copyright &copy;Apex 2018. <a href="https://www.expertwebtech.com/">Designed and Developed by Xpert Webtech Pvt Ltd</a>.</strong> All rights reserved.
</footer>
 