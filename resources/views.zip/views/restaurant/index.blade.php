@extends('master') 
@section('title','Dashboard')
@section('main_body')
@include('layouts.section')
@endsection