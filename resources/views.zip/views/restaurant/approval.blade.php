@extends('master') 
@section('main_body')
<div class="col-md-3"></div>
<div class="col-md-6" style="margin-top:50px;"> <br>
	<div class="box box-primary">
		<div class="box-header with-border">
		  <h3 class="box-title">Waiting For Approval</h3>
		</div> 
	</div>
</div>
@endsection